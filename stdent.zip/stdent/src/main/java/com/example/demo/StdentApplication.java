package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StdentApplication {

	public static void main(String[] args) {
		SpringApplication.run(StdentApplication.class, args);
	}

}
