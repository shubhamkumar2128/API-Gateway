package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity

public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	long empCode;
	String fNname;
	String lName;
	String email;

	public Employee() {
		super();
	}

	public Employee(String fNname, String lName, String email) {
		super();
		this.fNname = fNname;
		this.lName = lName;
		this.email = email;
	}

	
	public long getEmpCode() {
		return empCode;
	}

	public void setEmpCode(long empCode) {
		this.empCode = empCode;
	}

	public String getfNname() {
		return fNname;
	}

	public void setfNname(String fNname) {
		this.fNname = fNname;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
