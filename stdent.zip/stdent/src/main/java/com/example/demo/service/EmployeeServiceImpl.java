package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

	@Override
	public Employee createEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return employeeRepository.save(emp);
	}

	@Override
	public Employee getEmployeeById(long id) {
		// TODO Auto-generated method stub

		Optional<Employee> findById = employeeRepository.findById(id);
		if (findById.isPresent())
			return findById.get();
		else
			return null;

	}

	@Override
	public Employee deleteEmployee(long id) {
		Employee employee = null;
		Optional<Employee> findById = employeeRepository.findById(id);
		if (findById.isPresent()) {
			employee = findById.get();
			employeeRepository.delete(employee);
			return new Employee("", "Deleted", "");
		} else
			return new Employee("", "Not Deleted", "");

	}

	@Override
	public Employee updateEmployee(long id, Employee employeeDetails) {
		Employee employee = null;
		Optional<Employee> findById = employeeRepository.findById(id);
		if (findById.isPresent())
			employee = findById.get();
		else
			return null;

		employee.setfNname(employeeDetails.getfNname());
		employee.setlName(employeeDetails.getlName());
		employee.setEmail(employeeDetails.getEmail());

		Employee updatedEmployee = employeeRepository.save(employee);
		return updatedEmployee;
	}

}
